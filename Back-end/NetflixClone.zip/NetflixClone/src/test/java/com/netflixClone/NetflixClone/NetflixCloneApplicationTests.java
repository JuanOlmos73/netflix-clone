package com.netflixClone.NetflixClone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
